package com.cyn.assistant.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Подключение к языковой модели. Два формата:
 *  - "openai": любой OpenAI-совместимый /chat/completions (OpenAI, OpenRouter, локальные серверы и т.д.)
 *  - "anthropic": Claude Messages API
 * Ключ берётся из SecureStore.
 */
object Llm {
    const val OPENAI_URL = "https://api.openai.com/v1"
    const val OPENAI_MODEL = "gpt-4o-mini"
    const val ANTHROPIC_URL = "https://api.anthropic.com"
    const val ANTHROPIC_MODEL = "claude-haiku-5-5"

    /** msgs: пары (role, text), role = "user" | "assistant". */
    suspend fun chat(ctx: Context, prefs: Prefs, system: String, msgs: List<Pair<String, String>>): String {
        val key = SecureStore.get(ctx) ?: error("API-ключ не задан")
        val clean = msgs.dropWhile { it.first == "assistant" }
        return if (prefs.provider == "anthropic") anthropic(prefs, key, system, clean)
        else openai(prefs, key, system, clean)
    }

    private suspend fun openai(p: Prefs, key: String, system: String, msgs: List<Pair<String, String>>): String {
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("model", p.model).put("messages", arr).put("temperature", 0.9)
        val res = Http.request(
            p.baseUrl.trimEnd('/') + "/chat/completions",
            "POST",
            mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key"),
            body.toString(),
        )
        return JSONObject(res).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim()
    }

    private suspend fun anthropic(p: Prefs, key: String, system: String, msgs: List<Pair<String, String>>): String {
        val arr = JSONArray()
        msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject()
            .put("model", p.model)
            .put("max_tokens", 400)
            .put("system", system)
            .put("messages", arr)
        val res = Http.request(
            p.baseUrl.trimEnd('/') + "/v1/messages",
            "POST",
            mapOf(
                "Content-Type" to "application/json",
                "x-api-key" to key,
                "anthropic-version" to "2023-06-01",
            ),
            body.toString(),
        )
        val content = JSONObject(res).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString().trim()
    }
}
