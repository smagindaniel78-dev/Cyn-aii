package com.cyn.assistant.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

object NativeBrain {
    init { System.loadLibrary("cynbrain") }
    external fun epoch(): Long
    external fun cancel()
    external fun generate(path: String, prompt: ByteArray, epoch: Long): ByteArray
}

object LocalLlm {
    private val lock = Mutex()
    @Volatile private var loaded = false
    fun cancel() { if (loaded) NativeBrain.cancel() }
    // Fixed template for this pinned Qwen model. Literal chat delimiters are not user content.
    private fun clean(s: String) = s.replace("<|", "‹|").replace("|>", "|›")
    fun prompt(memory: List<String>, messages: List<Pair<String, String>>): String {
        val system = clean(Personality.systemPrompt(memory))
        val recent = messages.takeLast(3).dropWhile { it.first != "user" }
        return buildString {
            append("<|im_start|>system\n$system<|im_end|>\n")
            recent.forEach { (role, text) ->
                append("<|im_start|>${if (role == "user") "user" else "assistant"}\n${clean(text.take(600))}<|im_end|>\n")
            }
            append("<|im_start|>assistant\n")
        }
    }
    suspend fun chat(store: LocalModelStore, memory: List<String>, messages: List<Pair<String, String>>): String {
        if (!store.isReady()) return "Босяра, скачай мой локальный мозг: Настройки → ИИ → Скачать модель. Ключ и оплата не нужны."
        if ((messages.lastOrNull()?.second?.length ?: 0) > 600) return "Для локального мозга напиши покороче: до 600 символов, Босяра."
        return withContext(Dispatchers.IO) {
            lock.withLock {
                currentCoroutineContext().ensureActive()
                val epoch = try { NativeBrain.epoch() } catch (e: LinkageError) {
                    throw IllegalStateException("Этот телефон не поддерживает локальный движок ARM64", e)
                }
                loaded = true
                currentCoroutineContext().ensureActive()
                val output = NativeBrain.generate(store.file.absolutePath, prompt(memory, messages).toByteArray(Charsets.UTF_8), epoch)
                currentCoroutineContext().ensureActive()
                output.toString(Charsets.UTF_8).trim().ifEmpty { "Не получилось сформулировать ответ. Попробуй спросить короче, Босяра." }
            }
        }
    }
}
