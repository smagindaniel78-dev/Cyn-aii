package com.cyn.assistant.core

import kotlinx.coroutines.flow.MutableStateFlow

enum class Mood { IDLE, WAVE, JOY, SURPRISE, BORED, SLEEP, WALK, LISTEN, TALK, THINK }

/** Общее состояние персонажа: его читают и приложение, и плавающее окно. */
object CynState {
    val mood = MutableStateFlow(Mood.IDLE)
    /** Текст в облачке над персонажем (null = облачка нет). */
    val bubble = MutableStateFlow<String?>(null)
}
