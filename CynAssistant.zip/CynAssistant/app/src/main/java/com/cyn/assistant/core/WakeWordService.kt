package com.cyn.assistant.core

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import com.cyn.assistant.CynApp
import com.cyn.assistant.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Режим «Син, слушай». ДОБРОВОЛЬНЫЙ: включается переключателем в настройках, всё время виден
 * в шторке как уведомление с кнопкой «Выключить». Микрофон слушает через системный SpeechRecognizer
 * (с просьбой работать офлайн, если пакет языка установлен). Это не «настоящий» офлайн-детектор
 * wake-word: расходует батарею, на части телефонов распознаватель пикает при перезапуске.
 * После перезагрузки телефона сам НЕ запускается.
 */
class WakeWordService : Service() {
    companion object {
        const val CHANNEL = "cyn_wake"
        const val NOTIF_ID = 12
        const val ACTION_OFF = "com.cyn.assistant.WAKE_OFF"
        var running by mutableStateOf(false)
            private set

        fun isWake(text: String): Boolean {
            val t = text.lowercase().replace(",", " ").replace(Regex("\\s+"), " ")
            return t.contains("син слушай") || t.contains("сын слушай") || t.contains("сим слушай")
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var rec: SpeechRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Режим «Син, слушай»", NotificationManager.IMPORTANCE_LOW))
        val off = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_OFF),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_cyn)
            .setContentTitle("Микрофон включён: жду «Син, слушай»")
            .setContentText("Нажми «Выключить», чтобы остановить прослушивание")
            .setOngoing(true)
            .addAction(0, "Выключить", off)
            .build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIF_ID, n)

        if (!Perms.mic(this)) { stopSelf(); return }
        running = true
        scope.launch {
            val a = CynApp.assistant
            while (isActive) {
                if (a.listening || CynState.mood.value == Mood.TALK || CynState.mood.value == Mood.THINK) {
                    delay(800); continue
                }
                val heard = listenOnce()
                if (heard != null && isWake(heard)) a.onWake()
                delay(400)
            }
        }
    }

    private suspend fun listenOnce(): String? = suspendCancellableCoroutine { cont ->
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            cont.resume(null); return@suspendCancellableCoroutine
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        fun finish(v: String?) {
            if (cont.isActive) cont.resume(v)
            runCatching { r.destroy() }
            if (rec === r) rec = null
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) = finish(null)
            override fun onResults(results: Bundle?) =
                finish(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull())

            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (p != null && isWake(p)) finish(p)
            }
        })
        cont.invokeOnCancellation { runCatching { r.cancel(); r.destroy() } }
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_OFF) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        rec?.let { runCatching { it.cancel(); it.destroy() } }
        rec = null
        running = false
        super.onDestroy()
    }
}
