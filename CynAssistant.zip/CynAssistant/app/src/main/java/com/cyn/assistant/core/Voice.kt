package com.cyn.assistant.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/** Распознавание русской речи (SpeechRecognizer) и озвучка (TextToSpeech). Только главный поток. */
class Voice(private val ctx: Context, private val prefs: Prefs) {
    private var tts: TextToSpeech? = null
    private val ready = CompletableDeferred<Boolean>()
    private var recognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ru", "RU")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                ready.complete(r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED)
            } else ready.complete(false)
        }
    }

    private fun sanitize(text: String): String =
        text.replace(":3", "").replace(Regex("[\\p{So}\\p{Cn}]"), "").replace(Regex("\\s+"), " ").trim()

    /** Озвучивает текст и ждёт конца. Отмена корутины сразу останавливает речь. false = озвучить не вышло. */
    suspend fun speak(text: String): Boolean {
        if (withTimeoutOrNull(3000) { ready.await() } != true) return false
        val t = tts ?: return false
        val clean = sanitize(text)
        if (clean.isBlank()) return true
        t.setSpeechRate(prefs.ttsRate)
        t.setPitch(prefs.ttsPitch)
        return suspendCancellableCoroutine { cont ->
            val id = UUID.randomUUID().toString()
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(true)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(false)
                }
            })
            cont.invokeOnCancellation { t.stop() }
            t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
        }
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    /** Одна сессия распознавания, запускается только по действию пользователя. */
    fun listen(onPartialText: (String) -> Unit, onFinalText: (String) -> Unit, onFail: (String) -> Unit) {
        stopListening()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail("На этом телефоне нет службы распознавания речи.")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.let(onPartialText)
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                release(r)
                if (text.isBlank()) onFail("Ничего не расслышала, Босяра.") else onFinalText(text)
            }

            override fun onError(error: Int) {
                release(r)
                onFail(describe(error))
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        r.startListening(intent)
    }

    private fun release(r: SpeechRecognizer) {
        runCatching { r.destroy() }
        if (recognizer === r) recognizer = null
    }

    fun stopListening() {
        recognizer?.let { runCatching { it.cancel(); it.destroy() } }
        recognizer = null
    }

    fun stopAll() {
        stopListening()
        stopSpeaking()
    }

    private fun describe(code: Int) = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Не расслышала, Босяра. Попробуй ещё раз!"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет разрешения на микрофон."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
            "Распознаванию речи нужен интернет, а связи нет."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Распознаватель занят, подожди секунду."
        SpeechRecognizer.ERROR_AUDIO -> "Проблема с записью звука."
        else -> "Не вышло распознать речь (код $code)."
    }
}
