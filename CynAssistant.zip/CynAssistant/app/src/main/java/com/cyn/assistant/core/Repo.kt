package com.cyn.assistant.core

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val fromUser: Boolean, val text: String, val ts: Long)

/**
 * Локальное хранилище: память о пользователе, заметки и история диалога.
 * Всё лежит только на устройстве; просмотр и удаление — на вкладках «Память» и «История».
 * Память пополняется ТОЛЬКО по явной просьбе («запомни ...») или вручную.
 * Вызывать с главного потока.
 */
class Repo(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cyn_data", Context.MODE_PRIVATE)

    val memory = mutableStateListOf<String>()
    val notes = mutableStateListOf<String>()
    val history = mutableStateListOf<Msg>()

    init {
        loadStrings("memory", memory)
        loadStrings("notes", notes)
        runCatching {
            val arr = JSONArray(sp.getString("history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                history.add(Msg(o.getBoolean("u"), o.getString("t"), o.optLong("ts")))
            }
        }
    }

    private fun loadStrings(key: String, into: MutableList<String>) {
        runCatching {
            val arr = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until arr.length()) into.add(arr.getString(i))
        }
    }

    private fun saveStrings(key: String, list: List<String>) {
        sp.edit().putString(key, JSONArray(list).toString()).apply()
    }

    // --- память ---
    fun addMemory(text: String) {
        if (text.isBlank()) return
        memory.add(text.trim()); saveStrings("memory", memory)
    }

    fun removeMemory(index: Int) {
        if (index in memory.indices) { memory.removeAt(index); saveStrings("memory", memory) }
    }

    fun clearMemory() { memory.clear(); saveStrings("memory", memory) }

    // --- заметки ---
    fun addNote(text: String) {
        if (text.isBlank()) return
        notes.add(0, text.trim()); saveStrings("notes", notes)
    }

    fun removeNote(index: Int) {
        if (index in notes.indices) { notes.removeAt(index); saveStrings("notes", notes) }
    }

    fun clearNotes() { notes.clear(); saveStrings("notes", notes) }

    // --- история ---
    fun addMsg(fromUser: Boolean, text: String) {
        history.add(Msg(fromUser, text, System.currentTimeMillis()))
        while (history.size > 200) history.removeAt(0)
        val arr = JSONArray()
        history.forEach { arr.put(JSONObject().put("u", it.fromUser).put("t", it.text).put("ts", it.ts)) }
        sp.edit().putString("history", arr.toString()).apply()
    }

    fun clearHistory() {
        history.clear(); sp.edit().putString("history", "[]").apply()
    }
}
