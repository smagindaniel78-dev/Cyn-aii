package com.cyn.assistant.core

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/** Мозг приложения: принимает текст или речь, выполняет команды или спрашивает LLM, озвучивает ответ. */
class Assistant(private val app: Application) {
    val prefs = Prefs(app)
    val repo = Repo(app)
    val localModel = LocalModelStore(app)
    val voice = Voice(app, prefs)
    private val actions = Actions(app, prefs, repo)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var moodJob: Job? = null
    private var bubbleJob: Job? = null
    private var lastTouch = SystemClock.elapsedRealtime()

    var pending by mutableStateOf<Outcome.Confirm?>(null)
        private set
    var status by mutableStateOf("Готова. Чем помочь?")
        private set
    var listening by mutableStateOf(false)
        private set

    private val yes = Regex("^(да|ага|угу|давай|конечно|подтверждаю|ок|окей|хорошо|го)[.! ]*$")
    private val no = Regex("^(нет|не надо|отмена|отмени|не нужно|стоп)[.! ]*$")

    init {
        // «Жизнь» персонажа: скука, радость, сон. Лёгкий цикл, в режиме энергосбережения реже.
        scope.launch {
            while (true) {
                delay(if (prefs.energySaver) 15_000 else 6_000)
                if (CynState.mood.value != Mood.IDLE) continue
                val idle = SystemClock.elapsedRealtime() - lastTouch
                val sleepAfter = if (prefs.energySaver) 20_000 else 90_000
                if (idle > sleepAfter) setMood(Mood.SLEEP)
                else if (!prefs.energySaver && Random.nextInt(100) < 30) {
                    setMood(listOf(Mood.BORED, Mood.JOY, Mood.SURPRISE).random(), 2500)
                }
            }
        }
    }

    // ------------------------------------------------------------- состояние персонажа

    fun poke() {
        lastTouch = SystemClock.elapsedRealtime()
        if (CynState.mood.value == Mood.SLEEP) CynState.mood.value = Mood.IDLE
    }

    fun setMood(m: Mood, forMs: Long = 0L) {
        moodJob?.cancel()
        CynState.mood.value = m
        if (forMs > 0) moodJob = scope.launch {
            delay(forMs)
            if (CynState.mood.value == m) CynState.mood.value = Mood.IDLE
        }
    }

    fun showBubble(text: String, ms: Long = 3500L) {
        CynState.bubble.value = text
        bubbleJob?.cancel()
        bubbleJob = scope.launch { delay(ms); CynState.bubble.value = null }
    }

    fun onTap() {
        poke()
        setMood(Mood.WAVE, 1800)
        showBubble(Personality.tap())
    }

    fun onWake() {
        poke()
        showBubble(Personality.wake(), 2000)
        listen()
    }

    // ------------------------------------------------------------- ввод

    private fun hasMic() =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Слушает ТОЛЬКО после нажатия кнопки (или добровольно включённого «Син, слушай»). */
    fun listen() {
        poke()
        if (!hasMic()) {
            status = "Нужно разрешение на микрофон (вкладка «Права»)."
            showBubble(status)
            return
        }
        LocalLlm.cancel()
        job?.cancel()
        voice.stopSpeaking()
        listening = true
        status = "Слушаю..."
        setMood(Mood.LISTEN)
        CynState.bubble.value = "Слушаю..."
        voice.listen(
            onPartialText = { status = it },
            onFinalText = { listening = false; submit(it) },
            onFail = {
                listening = false
                status = it
                setMood(Mood.IDLE)
                showBubble(it)
            },
        )
    }

    fun submit(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        poke()
        LocalLlm.cancel()
        job?.cancel()
        job = scope.launch {
            repo.addMsg(true, text)
            status = if (prefs.provider == "local") "Думаю на телефоне… Это может занять время." else "Думаю..."
            setMood(Mood.THINK)
            val reply = try {
                process(text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Personality.error(e.message)
            }
            repo.addMsg(false, reply)
            say(reply)
        }
    }

    private suspend fun process(text: String): String {
        val low = text.lowercase().trim()
        val p = pending
        if (p != null) {
            pending = null
            if (yes.matches(low)) return p.run()
            if (no.matches(low)) return Personality.cancelled()
            // иначе подтверждение сбрасывается, и фраза обрабатывается как новая
        }
        when (val o = actions.handle(text)) {
            is Outcome.Reply -> return o.text
            is Outcome.Confirm -> {
                if (!prefs.confirmActions) return o.run()
                pending = o
                return Personality.ask(o.question)
            }
            null -> {}
        }
        return askLlm()
    }

    private suspend fun askLlm(): String {
        val msgs = repo.history.filter { it.ts >= prefs.plainDialogSince }.takeLast(12).map { (if (it.fromUser) "user" else "assistant") to it.text }
        if (prefs.provider == "local") return LocalLlm.chat(localModel, repo.memory.toList(), msgs)
        if (!SecureStore.has(app)) return Personality.noKey()
        return Llm.chat(app, prefs, Personality.systemPrompt(repo.memory.toList()), msgs)
    }

    private suspend fun say(text: String) {
        status = text
        bubbleJob?.cancel()
        CynState.bubble.value = text
        if (prefs.voiceOut) {
            setMood(Mood.TALK)
            voice.speak(text)
        } else {
            setMood(Mood.TALK, (900L + text.length * 25L).coerceAtMost(4000L))
        }
        if (CynState.mood.value == Mood.TALK) setMood(Mood.IDLE)
        showBubble(text, if (prefs.voiceOut) 1500 else 3500L + text.length * 40L)
    }

    /** Озвучить пример голоса из настроек. */
    fun testVoice() {
        LocalLlm.cancel()
        job?.cancel()
        job = scope.launch { say(Personality.greet()) }
    }

    // ------------------------------------------------------------- СТОП

    /**
     * Кнопка «СТОП»: немедленно обрывает ответ, речь, запись микрофона, сетевой запрос,
     * сбрасывает подтверждение и выключает режим «Син, слушай».
     */
    fun stopAll() {
        LocalLlm.cancel()
        job?.cancel()
        moodJob?.cancel()
        voice.stopAll()
        pending = null
        listening = false
        runCatching { app.stopService(Intent(app, WakeWordService::class.java)) }
        CynState.mood.value = Mood.IDLE
        status = "Стоп! Всё остановила."
        showBubble("Остановила ответ и микрофон.", 2500)
    }

    fun confirm(yesAnswer: Boolean) = submit(if (yesAnswer) "да" else "нет")
}
