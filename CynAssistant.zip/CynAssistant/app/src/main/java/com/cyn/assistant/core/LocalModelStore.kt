package com.cyn.assistant.core

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.security.MessageDigest

data class ModelState(val ready: Boolean = false, val busy: Boolean = false, val progress: Float = 0f,
                      val message: String = "Модель ещё не скачана")

/** Only the pinned, checksum-verified model can be loaded by the native engine. */
class LocalModelStore(private val ctx: Context) {
    companion object {
        const val SIZE = 1117320736L
        const val SHA = "6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"
        const val URL = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/91cad51170dc346986eccefdc2dd33a9da36ead9/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true"
    }
    private val prefs = ctx.getSharedPreferences("local_model_v15", Context.MODE_PRIVATE)
    private val dm = ctx.getSystemService(DownloadManager::class.java)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val folder = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "models").apply { mkdirs() }
    val file = File(folder, "qwen-cyn-1.5b.gguf")
    private val part = File(folder, "qwen-1.5b-download.part")
    private val mutable = MutableStateFlow(ModelState())
    val state = mutable.asStateFlow()
    private var task: Job? = null

    init {
        task = scope.launch {
            if (file.isFile) {
                mutable.value = ModelState(busy = true, message = "Проверяю модель…")
                if (withContext(Dispatchers.IO) { runCatching { valid(file) }.getOrDefault(false) }) {
                    markReady(); return@launch
                }
                file.delete()
            }
            val id = prefs.getLong("download", -1)
            if (id >= 0) monitor(id) else mutable.value = ModelState()
        }
    }

    private fun markReady() {
        // Remove the superseded downloadable model only once its replacement is verified.
        File(folder, "qwen-cyn.gguf").delete()
        prefs.edit().putLong("mtime", file.lastModified()).apply()
        mutable.value = ModelState(ready = true, progress = 1f, message = "Готова • ответы на телефоне")
    }
    fun isReady() = state.value.ready && file.length() == SIZE && file.lastModified() == prefs.getLong("mtime", -1)

    private fun valid(f: File): Boolean {
        if (f.length() != SIZE) return false
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().buffered().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) { val n = input.read(buffer); if (n < 0) break; md.update(buffer, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it.toInt() and 255) } == SHA
    }

    fun download(allowMobile: Boolean) {
        if (state.value.busy || isReady()) return
        task?.cancel()
        try {
            check(StatFs(folder.absolutePath).availableBytes > SIZE + 200_000_000L) { "Нужно хотя бы 1,4 ГБ свободного места" }
            part.delete()
            val request = DownloadManager.Request(Uri.parse(URL))
                .setTitle("Модель Син — Qwen 1.5B")
                .setDescription("1,12 ГБ • бесплатный локальный ИИ")
                .setDestinationUri(Uri.fromFile(part))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(allowMobile)
                .setAllowedOverRoaming(false)
            if (!allowMobile) request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI)
            val id = dm.enqueue(request)
            prefs.edit().putLong("download", id).apply()
            mutable.value = ModelState(busy = true, message = "Загрузка начинается…")
            task = scope.launch { monitor(id) }
        } catch (e: Exception) {
            mutable.value = ModelState(message = "Не удалось начать: ${e.message}")
        }
    }

    private suspend fun monitor(id: Long) {
        try {
            while (currentCoroutineContext().isActive) {
                val done = dm.query(DownloadManager.Query().setFilterById(id)).use { c ->
                    check(c != null && c.moveToFirst()) { "Загрузка удалена. Нажми «Скачать» ещё раз." }
                    val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val bytes = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val p = (bytes.toFloat() / SIZE).coerceIn(0f, 1f)
                    when (status) {
                        DownloadManager.STATUS_FAILED -> error("Ошибка загрузки (${c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))}). Проверь сеть и свободное место.")
                        DownloadManager.STATUS_SUCCESSFUL -> true
                        else -> {
                            val msg = if (status == DownloadManager.STATUS_PAUSED || status == DownloadManager.STATUS_PENDING)
                                "Ожидаю сеть / Wi-Fi…" else "Скачано ${bytes / 1_000_000} из 1117 МБ"
                            mutable.value = ModelState(busy = true, progress = p, message = msg)
                            false
                        }
                    }
                }
                if (done) {
                    mutable.value = ModelState(busy = true, progress = 1f, message = "Проверяю целостность модели…")
                    check(withContext(Dispatchers.IO) { valid(part) }) { "Файл повреждён. Скачай модель ещё раз." }
                    currentCoroutineContext().ensureActive()
                    check(part.renameTo(file)) { "Не удалось сохранить модель" }
                    prefs.edit().remove("download").apply()
                    markReady()
                    return
                }
                delay(1000)
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            dm.remove(id); part.delete()
            prefs.edit().remove("download").apply()
            mutable.value = ModelState(message = e.message ?: "Ошибка загрузки")
        }
    }

    fun remove() {
        task?.cancel()
        val id = prefs.getLong("download", -1)
        if (id >= 0) dm.remove(id)
        prefs.edit().clear().apply()
        LocalLlm.cancel()
        part.delete(); file.delete()
        mutable.value = ModelState(message = "Модель удалена. Можно скачать заново.")
    }
}
