package com.cyn.assistant.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cyn.assistant.CynApp

val NeonYellow = Color(0xFFFFE600)
val DeepBlack = Color(0xFF000000)
val PanelBg = Color(0xFF0E0E08)
val DimYellow = Color(0xFF8A7F00)
val Danger = Color(0xFFFF3B30)
val SoftWhite = Color(0xFFF2F2E0)

private val scheme = darkColorScheme(
    primary = NeonYellow,
    onPrimary = Color.Black,
    secondary = Color(0xFFFFB800),
    background = DeepBlack,
    onBackground = SoftWhite,
    surface = PanelBg,
    onSurface = SoftWhite,
    surfaceVariant = Color(0xFF1A1A10),
    onSurfaceVariant = Color(0xFFCFCF9A),
    error = Danger,
    outline = DimYellow,
)

private fun typography(): Typography {
    val b = Typography()
    val mono = FontFamily.Monospace
    return Typography(
        titleLarge = b.titleLarge.copy(fontFamily = mono, fontWeight = FontWeight.Bold),
        titleMedium = b.titleMedium.copy(fontFamily = mono),
        bodyLarge = b.bodyLarge.copy(fontFamily = mono),
        bodyMedium = b.bodyMedium.copy(fontFamily = mono),
        bodySmall = b.bodySmall.copy(fontFamily = mono),
        labelLarge = b.labelLarge.copy(fontFamily = mono, fontWeight = FontWeight.Bold),
        labelMedium = b.labelMedium.copy(fontFamily = mono),
        labelSmall = b.labelSmall.copy(fontFamily = mono),
    )
}

@Composable
fun CynTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography(), content = content)
}

private val panelShape = CutCornerShape(topStart = 14.dp, bottomEnd = 14.dp)

/** Футуристическая панель с пульсирующей неоново-жёлтой рамкой (пульс отключается в энергосбережении). */
@Composable
fun NeonPanel(modifier: Modifier = Modifier, title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val animate = !CynApp.assistant.prefs.energySaver
    val alpha: Float = if (animate) {
        val inf = rememberInfiniteTransition(label = "glow")
        val v by inf.animateFloat(0.4f, 0.95f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "a")
        v
    } else 0.8f
    Column(
        modifier
            .fillMaxWidth()
            .background(PanelBg, panelShape)
            .border(1.dp, NeonYellow.copy(alpha = alpha), panelShape)
            .padding(12.dp),
    ) {
        if (title != null) {
            Text(title.uppercase(), color = NeonYellow, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))
        }
        content()
    }
}

@Composable
fun NeonButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = NeonYellow, contentColor = Color.Black),
    ) { Text(text, style = MaterialTheme.typography.labelLarge) }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        shape = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp),
        border = BorderStroke(1.dp, NeonYellow),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonYellow),
    ) { Text(text, style = MaterialTheme.typography.labelLarge) }
}

@Composable
fun StopButton(modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Danger, contentColor = Color.White),
    ) { Text("⛔ СТОП", style = MaterialTheme.typography.labelLarge) }
}
