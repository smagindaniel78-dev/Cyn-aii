package com.cyn.assistant.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.cyn.assistant.core.Mood
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

private const val TAU = (2 * PI).toFloat()

private val HeadC = Color(0xFF8B7BFF)
private val HeadDark = Color(0xFF5B4BD0)
private val ScreenC = Color(0xFF0B1020)
private val EyeC = Color(0xFF5CF2FF)
private val BodyC = Color(0xFF2DD4BF)
private val LimbC = Color(0xFF6D5BD0)
private val FootC = Color(0xFF3B2F9E)
private val GlowC = Color(0xFFFFE600)
private val BlushC = Color(0xFFFF8FB1)

@Composable
fun rememberSprite(path: String): ImageBitmap? = remember(path) {
    if (path.isBlank()) null else runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull()
}

@Composable
private fun animatedTime(animate: Boolean): State<Float> {
    if (!animate) return remember { mutableFloatStateOf(0f) }
    val inf = rememberInfiniteTransition(label = "avatar")
    return inf.animateFloat(
        initialValue = 0f,
        targetValue = TAU,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "t",
    )
}

/**
 * Оригинальный маленький дрон-помощник, нарисованный кодом (Canvas), с анимациями:
 * болтает ногами, машет рукой, радость, удивление, скука, сон, ходьба, слушает, говорит, думает.
 * Если пользователь выбрал свой спрайт (PNG), вместо дрона анимируется он.
 * Логическое полотно 200x240, масштабируется под размер.
 */
@Composable
fun CynAvatar(
    mood: Mood,
    modifier: Modifier = Modifier,
    facingRight: Boolean = true,
    animate: Boolean = true,
    sprite: ImageBitmap? = null,
) {
    val time = animatedTime(animate)
    Canvas(modifier) {
        val s = size.width / 200f
        withTransform({
            scale(s, s, pivot = Offset.Zero)
            if (!facingRight) scale(-1f, 1f, pivot = Offset(100f, 0f))
        }) {
            val t = time.value
            if (sprite != null) drawSprite(sprite, mood, t) else drawDrone(mood, t)
        }
    }
}

private fun DrawScope.drawSprite(img: ImageBitmap, mood: Mood, t: Float) {
    val k = min(200f / img.width, 240f / img.height)
    val w = img.width * k
    val h = img.height * k
    var dy = 0f
    var rot = 0f
    var sx = 1f
    var sy = 1f
    when (mood) {
        Mood.WALK -> { dy = -abs(sin(t * 2f)) * 8f; rot = sin(t * 2f) * 4f }
        Mood.JOY -> dy = -abs(sin(t * 3f)) * 16f
        Mood.WAVE -> rot = sin(t * 4f) * 8f
        Mood.SURPRISE -> { sy = 1.1f; sx = 0.92f }
        Mood.SLEEP -> { rot = 6f; sy = 0.96f }
        Mood.BORED -> rot = sin(t) * 2f
        Mood.LISTEN -> sx = 1f + 0.03f * sin(t * 4f)
        Mood.THINK -> rot = -4f + sin(t) * 2f
        Mood.TALK -> dy = -abs(sin(t * 5f)) * 3f
        else -> dy = sin(t) * 2f
    }
    val pivot = Offset(100f, 240f)
    translate(0f, dy) {
        rotate(rot, pivot) {
            scale(sx, sy, pivot) {
                drawImage(
                    img,
                    dstOffset = IntOffset(((200f - w) / 2f).toInt(), (240f - h).toInt()),
                    dstSize = IntSize(w.toInt(), h.toInt()),
                )
            }
        }
    }
}

private fun DrawScope.drawZ(x: Float, y: Float, s: Float, c: Color) {
    val st = 2f
    drawLine(c, Offset(x, y), Offset(x + s, y), st, StrokeCap.Round)
    drawLine(c, Offset(x + s, y), Offset(x, y + s), st, StrokeCap.Round)
    drawLine(c, Offset(x, y + s), Offset(x + s, y + s), st, StrokeCap.Round)
}

private fun DrawScope.drawDrone(mood: Mood, t: Float) {
    val sw = sin(t)
    val bob = when (mood) {
        Mood.JOY -> -abs(sin(t * 3f)) * 12f
        Mood.SURPRISE -> -8f
        Mood.WALK -> -abs(sin(t * 2f)) * 5f
        Mood.SLEEP -> sw * 1.5f
        else -> sw * 2f
    }
    val legSwing = when (mood) {
        Mood.WALK -> sin(t * 2f) * 38f
        Mood.JOY -> sin(t * 3f) * 26f
        Mood.SLEEP -> 0f
        Mood.SURPRISE -> 10f
        else -> sw * 16f
    }

    translate(0f, bob) {
        // ноги (болтаются)
        listOf(86f, 114f).forEachIndexed { i, px ->
            val ang = if (i == 0) legSwing else -legSwing
            rotate(ang, Offset(px, 170f)) {
                drawRoundRect(LimbC, Offset(px - 6f, 168f), Size(12f, 40f), CornerRadius(6f))
                drawRoundRect(FootC, Offset(px - 10f, 202f), Size(22f, 10f), CornerRadius(5f))
            }
        }

        // тело + огонёк на груди
        drawRoundRect(BodyC, Offset(70f, 120f), Size(60f, 56f), CornerRadius(16f))
        drawCircle(GlowC.copy(alpha = 0.65f + 0.35f * sin(t * 2f)), 6f, Offset(100f, 150f))

        // руки
        val waveR = when (mood) {
            Mood.WAVE -> -(140f + sin(t * 4f) * 22f)
            Mood.JOY -> -(135f + sin(t * 3f) * 18f)
            Mood.SURPRISE -> -50f
            else -> -(8f + sin(t + 1f) * 6f)
        }
        val waveL = when (mood) {
            Mood.JOY -> 135f + sin(t * 3f + 1f) * 18f
            Mood.SURPRISE -> 50f
            else -> 8f + sin(t) * 6f
        }
        rotate(waveL, Offset(70f, 132f)) {
            drawRoundRect(LimbC, Offset(60f, 128f), Size(10f, 36f), CornerRadius(5f))
        }
        rotate(waveR, Offset(130f, 132f)) {
            drawRoundRect(LimbC, Offset(130f, 128f), Size(10f, 36f), CornerRadius(5f))
        }

        // антенна
        val sway = sin(t) * 3f
        drawLine(HeadDark, Offset(100f, 32f), Offset(100f + sway, 14f), 5f, StrokeCap.Round)
        drawCircle(GlowC.copy(alpha = 0.55f + 0.45f * abs(sin(t * 2f))), 7f, Offset(100f + sway, 10f))

        // голова
        drawRoundRect(HeadDark, Offset(38f, 62f), Size(12f, 28f), CornerRadius(6f))
        drawRoundRect(HeadDark, Offset(150f, 62f), Size(12f, 28f), CornerRadius(6f))
        drawRoundRect(HeadC, Offset(45f, 30f), Size(110f, 94f), CornerRadius(34f))
        drawRoundRect(ScreenC, Offset(56f, 44f), Size(88f, 64f), CornerRadius(22f))

        // глаза
        val blink = (t / TAU) % 1f > 0.94f
        val ex = listOf(80f, 120f)
        val ey = 74f
        val lookX = if (mood == Mood.THINK) 4f else 0f
        val lookY = if (mood == Mood.THINK) -5f else 0f
        when (mood) {
            Mood.JOY -> ex.forEach {
                drawArc(EyeC, 200f, 140f, false, Offset(it - 9f, ey - 6f), Size(18f, 16f), style = Stroke(4.5f, cap = StrokeCap.Round))
            }
            Mood.SLEEP -> ex.forEach {
                drawArc(EyeC, 20f, 140f, false, Offset(it - 9f, ey - 8f), Size(18f, 16f), style = Stroke(4f, cap = StrokeCap.Round))
            }
            Mood.SURPRISE -> ex.forEach { drawCircle(EyeC, 11f, Offset(it, ey)) }
            Mood.BORED -> ex.forEach {
                drawRoundRect(EyeC, Offset(it - 9f, ey), Size(18f, 5f), CornerRadius(2.5f))
            }
            else -> ex.forEach {
                val hh = if (blink) 3f else 22f
                drawRoundRect(
                    EyeC,
                    Offset(it - 7f + lookX, ey - 11f + lookY + (22f - hh) / 2f),
                    Size(14f, hh),
                    CornerRadius(7f),
                )
            }
        }

        // рот
        val mc = EyeC
        when (mood) {
            Mood.TALK -> drawOval(mc, Offset(94f, 91f), Size(12f, 4f + abs(sin(t * 6f)) * 8f))
            Mood.JOY -> drawArc(mc, 20f, 140f, false, Offset(90f, 88f), Size(20f, 12f), style = Stroke(3f, cap = StrokeCap.Round))
            Mood.SURPRISE -> drawCircle(mc, 5f, Offset(100f, 97f), style = Stroke(3f))
            Mood.BORED -> drawLine(mc, Offset(93f, 97f), Offset(107f, 97f), 3f, StrokeCap.Round)
            Mood.SLEEP -> drawCircle(mc, 2.5f, Offset(100f, 96f))
            else -> drawArc(mc, 20f, 140f, false, Offset(93f, 90f), Size(14f, 8f), style = Stroke(2.5f, cap = StrokeCap.Round))
        }

        // румянец
        drawCircle(BlushC.copy(alpha = 0.55f), 6f, Offset(66f, 96f))
        drawCircle(BlushC.copy(alpha = 0.55f), 6f, Offset(134f, 96f))

        // эффекты состояний
        when (mood) {
            Mood.SLEEP -> for (k in 0..2) {
                val p = ((t / TAU) + k / 3f) % 1f
                drawZ(150f + p * 14f, 40f - p * 30f, 6f + k * 2f, Color.White.copy(alpha = 1f - p))
            }
            Mood.LISTEN -> for (k in 1..2) {
                val r = 14f + k * 8f + sin(t * 3f) * 2f
                drawArc(
                    EyeC.copy(alpha = 0.8f - k * 0.25f), -45f, 90f, false,
                    Offset(156f - r, 76f - r), Size(2 * r, 2 * r), style = Stroke(3f, cap = StrokeCap.Round),
                )
            }
            Mood.THINK -> for (k in 0..2) {
                drawCircle(Color.White.copy(alpha = 0.4f + 0.6f * abs(sin(t * 3f - k))), 3f, Offset(150f + k * 11f, 30f))
            }
            else -> {}
        }
    }
}
