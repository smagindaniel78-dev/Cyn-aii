package com.cyn.assistant.core

import android.app.Application
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.net.URLEncoder

sealed interface Outcome {
    data class Reply(val text: String) : Outcome

    /** Действие, которое выполнится только после «да» от пользователя. */
    data class Confirm(val question: String, val run: suspend () -> String) : Outcome
}

/**
 * Реальные команды телефона через официальные Intent и системные API.
 * Возвращает null, если фраза — не команда (тогда отвечает языковая модель).
 * Ничего не изображает: если Android не даёт что-то сделать, об этом честно сказано в ответе.
 */
class Actions(
    private val app: Application,
    private val prefs: Prefs,
    private val repo: Repo,
) {
    private val numWords = mapOf(
        "один" to 1, "одну" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4,
        "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10,
        "пятнадцать" to 15, "двадцать" to 20, "тридцать" to 30, "сорок" to 40,
        "пятьдесят" to 50, "шестьдесят" to 60,
    )

    private val appAliases = mapOf(
        "телеграм" to "telegram", "телеграмм" to "telegram", "ватсап" to "whatsapp", "вотсап" to "whatsapp",
        "ютуб" to "youtube", "камера" to "camera", "камеру" to "camera", "калькулятор" to "calculator",
        "часы" to "clock", "галерея" to "gallery", "галерею" to "gallery", "карты" to "maps",
        "почта" to "gmail", "почту" to "gmail", "хром" to "chrome", "гугл" to "google",
        "контакты" to "contacts", "телефон" to "phone", "сообщения" to "messages",
        "календарь" to "calendar", "файлы" to "files", "плей маркет" to "play store",
        "спотифай" to "spotify", "дискорд" to "discord", "инстаграм" to "instagram", "тикток" to "tiktok",
    )

    suspend fun handle(raw: String): Outcome? {
        val t = raw.lowercase().replace('ё', 'е').trim().trimEnd('.', '!', '?', ' ')
            .replace(Regex("^син[,\\s]+"), "")
        fun has(vararg w: String) = w.any { t.contains(it) }
        fun reply(s: String) = Outcome.Reply(s)

        // --- запросы, которые Android не позволяет выполнить: говорим честно ---
        if (has("отправь", "перешли") && has("сообщен", "смс", "файл", "фото")) {
            return reply(Personality.limit("Отправлять сообщения и файлы я не умею — это слишком важное действие, и я не хочу делать его за тебя. Могу составить текст, а отправишь ты сам!"))
        }
        if (has("wi-fi", "wifi", "вай-фай", "вайфай", "блютуз", "bluetooth", "режим полета", "мобильные данные", "мобильный интернет") && has("включи", "выключи", "отключи")) {
            return reply(Personality.limit("Начиная с Android 10 приложения не могут сами переключать Wi-Fi, Bluetooth и режим полёта. Скажи «открой настройки wi-fi» — открою нужный экран, и там нажмёшь сам."))
        }

        // --- простые безопасные команды (без подтверждения) ---
        if (has("батаре", "заряд")) return reply(battery())

        if (has("фонарик", "фонарь")) {
            val on = !has("выключи", "погаси", "отключи")
            return reply(torch(on))
        }

        if (has("громче", "потише", "тише", "громкост", "без звука", "выключи звук")) return reply(volume(t))

        if (has("пауза", "поставь на паузу", "останови музыку", "следующий трек", "следующая песня", "следующую", "предыдущий трек", "предыдущая песня", "продолжи музыку", "верни музыку")) {
            return reply(mediaControl(t))
        }

        if (t.startsWith("запомни")) {
            val what = t.removePrefix("запомни").trim().removePrefix("что").trim()
            if (what.isBlank()) return reply("Что запомнить? Скажи: «запомни, что я люблю чай».")
            repo.addMemory(what)
            return reply(Personality.ok("Запомнила: «$what». Посмотреть и удалить можно на вкладке «Память»."))
        }

        if (has("заметк") || t.startsWith("запиши")) {
            val text = t.replace(Regex("^(создай|сделай|добавь|запиши)\\s+(мне\\s+)?(новую\\s+)?заметк\\S*\\s*(что|:)?\\s*"), "")
                .removePrefix("запиши").trim().removePrefix("что").trim()
            if (text.isBlank() || text.contains("заметк")) return reply("Что записать в заметку, Босяра? Скажи: «создай заметку купить хлеб».")
            repo.addNote(text)
            return reply(Personality.ok("Записала в заметки внутри приложения (вкладка «Память»): «$text». В другие приложения-блокноты я сама не пишу."))
        }

        if (has("погод")) return reply(weather(t))

        if (has("уведомлен")) return reply(notifications())

        // --- настройки ---
        if (has("настройк") && has("открой", "покажи", "зайди", "включи")) return reply(openSettings(t))

        // --- поиск в интернете / YouTube / браузер ---
        if (has("ютуб", "youtube") && has("найди", "поищи", "покажи")) {
            val q = t.substringAfter("ютубе", "").ifBlank { t.substringAfter("ютуб", "") }
                .ifBlank { t.substringAfter("youtube", "") }.replace(Regex("^(на|в)\\s+"), "").trim()
            return if (q.isBlank()) null else reply(start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(q)}")), "Открыла поиск на YouTube по запросу «$q»."))
        }
        if (t.startsWith("загугли") || t.startsWith("поищи") || t.startsWith("найди в интернете") || t.startsWith("найди в гугле") || t.startsWith("поиск")) {
            val q = t.replace(Regex("^(загугли|поищи в интернете|поищи|найди в интернете|найди в гугле|поиск)\\s*"), "").trim()
            if (q.isBlank()) return reply("Что искать, Босяра?")
            return reply(start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(q)}")), "Открыла поиск в браузере: «$q»."))
        }
        if (has("браузер") && has("открой", "запусти", "включи")) {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)
            return reply(start(i, "Открыла браузер."))
        }

        // --- команды с подтверждением ---
        if (has("таймер") && has("поставь", "запусти", "засеки", "включи", "создай", "на ")) return timer(t)
        if (has("будильник")) return alarm(t)

        if (has("музык", "песн", "трек", "композиц") && has("включи", "поставь", "запусти", "играй", "найди")) {
            return music(t)
        }

        if (Regex("^(открой|запусти|включи|зайди в)\\s+.+").matches(t)) {
            val name = t.replace(Regex("^(открой|запусти|включи|зайди в)\\s+(приложение\\s+)?"), "").trim()
            return openApp(name)
        }
        return null
    }

    // ---------------------------------------------------------------- помощники

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun start(i: Intent, okText: String): String = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(i)
        Personality.ok(okText)
    } catch (e: ActivityNotFoundException) {
        Personality.limit("На телефоне нет приложения, которое умеет это открыть.")
    } catch (e: SecurityException) {
        Personality.limit("Android не разрешил мне это открыть.")
    }

    private fun normalizeNumbers(s: String): String {
        var r = s.replace("полчаса", "30 минут").replace("полтора часа", "90 минут")
        r = r.split(" ").joinToString(" ") { numWords[it]?.toString() ?: it }
        return r
    }

    private fun battery(): String {
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        if (level < 0 || scale <= 0) return Personality.limit("Не смогла прочитать заряд батареи.")
        val pct = level * 100 / scale
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val tail = when {
            charging -> "Телефон сейчас заряжается."
            pct <= 15 -> "Мало! Найди зарядку, Босяра!"
            else -> "Пока живём!"
        }
        return Personality.ok("Заряд: $pct%. $tail")
    }

    private fun torch(on: Boolean): String = try {
        val cm = app.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) Personality.limit("У телефона нет вспышки для фонарика.")
        else {
            cm.setTorchMode(id, on)
            Personality.ok(if (on) "Фонарик включён." else "Фонарик выключен.")
        }
    } catch (e: Exception) {
        Personality.limit("Не получилось управлять фонариком: ${e.message}")
    }

    private fun volume(t: String): String {
        val am = app.getSystemService(AudioManager::class.java)
        val flags = AudioManager.FLAG_SHOW_UI
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val pct = Regex("(\\d{1,3})\\s*(%|процент)?").find(normalizeNumbers(t))?.groupValues?.get(1)?.toIntOrNull()
        return try {
            when {
                t.contains("без звука") || t.contains("выключи звук") -> {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, flags)
                    Personality.ok("Звук мультимедиа выключен.")
                }
                t.contains("громкость") && pct != null -> {
                    val v = (pct.coerceIn(0, 100) * max / 100)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, v, flags)
                    Personality.ok("Громкость мультимедиа — около $pct%.")
                }
                t.contains("громче") || t.contains("прибавь") -> {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, flags)
                    Personality.ok("Сделала громче.")
                }
                t.contains("тише") || t.contains("потише") || t.contains("убавь") -> {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, flags)
                    Personality.ok("Сделала тише.")
                }
                else -> Personality.limit("Скажи «громче», «тише» или «громкость на 40 процентов». Громкость звонка и режим «Не беспокоить» мне Android не отдаёт.")
            }
        } catch (e: SecurityException) {
            Personality.limit("Android не разрешил менять громкость сейчас (возможно, включён режим «Не беспокоить»).")
        }
    }

    private fun mediaKey(code: Int) {
        val am = app.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun mediaControl(t: String): String {
        val (code, what) = when {
            t.contains("следующ") -> KeyEvent.KEYCODE_MEDIA_NEXT to "Переключила на следующий трек"
            t.contains("предыдущ") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Вернула предыдущий трек"
            t.contains("продолж") || t.contains("верни") -> KeyEvent.KEYCODE_MEDIA_PLAY to "Нажала «играть»"
            else -> KeyEvent.KEYCODE_MEDIA_PAUSE to "Нажала паузу"
        }
        mediaKey(code)
        return Personality.ok("$what. Я шлю системную медиа-кнопку: сработает, если какой-то плеер сейчас активен.")
    }

    private fun timer(t: String): Outcome {
        val n = normalizeNumbers(t)
        var sec = 0
        Regex("(\\d+)\\s*(секунд|сек|минут|мин|час)").findAll(n).forEach {
            val v = it.groupValues[1].toInt()
            sec += when {
                it.groupValues[2].startsWith("сек") -> v
                it.groupValues[2].startsWith("мин") -> v * 60
                else -> v * 3600
            }
        }
        if (sec <= 0) return Outcome.Reply("На сколько ставить таймер, Босяра? Например: «поставь таймер на 10 минут».")
        val label = if (sec >= 3600) "${sec / 3600} ч ${sec % 3600 / 60} мин" else if (sec >= 60) "${sec / 60} мин ${sec % 60} сек" else "$sec сек"
        return Outcome.Confirm("Поставить таймер на $label?") {
            start(
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Син")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                "Таймер на $label запущен в приложении «Часы».",
            )
        }
    }

    private fun alarm(t: String): Outcome {
        val n = normalizeNumbers(t)
        val m = Regex("(?:на|в|к)\\s*(\\d{1,2})(?:[:. ](\\d{2}))?\\s*(утра|вечера|дня|ночи)?").find(n)
            ?: return Outcome.Reply("На какое время будильник? Например: «поставь будильник на 7:30».")
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifBlank { "0" }.toInt()
        when (m.groupValues[3]) {
            "вечера", "дня" -> if (h < 12) h += 12
            "ночи" -> if (h == 12) h = 0
        }
        if (h > 23 || min > 59) return Outcome.Reply("Такого времени не бывает. Укажи часы от 0 до 23 и минуты от 0 до 59.")
        val hh = h
        val label = "%d:%02d".format(hh, min)
        return Outcome.Confirm("Поставить будильник на $label?") {
            start(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hh)
                    .putExtra(AlarmClock.EXTRA_MINUTES, min)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Син")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                "Будильник на $label поставлен в приложении «Часы».",
            )
        }
    }

    private fun music(t: String): Outcome {
        val q = t.replace(Regex("^(включи|поставь|запусти|играй|найди)\\s+"), "")
            .replace(Regex("^(мне\\s+)?(музыку|музыка|песню|песня|трек|композицию)\\s*"), "").trim()
        if (q.isBlank()) {
            return Outcome.Confirm("Нажать «играть» в активном плеере?") {
                mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
                Personality.ok("Нажала «играть». Если плеер не запущен, ничего не случится — Android не даёт мне запускать музыку сам.")
            }
        }
        return Outcome.Confirm("Попросить музыкальное приложение найти и включить «$q»?") {
            val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(SearchManager.QUERY, q)
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                app.startActivity(i)
                Personality.ok("Отправила запрос «$q» музыкальному приложению. Включится ли именно этот трек — решает само приложение.")
            } catch (e: ActivityNotFoundException) {
                start(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(q)}")),
                    "Музыкального приложения с таким поиском нет, поэтому открыла поиск «$q» на YouTube.",
                )
            }
        }
    }

    private fun findApp(query: String): Pair<String, Intent>? {
        val pm = app.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q1 = query.lowercase().replace('ё', 'е').trim()
        val queries = listOfNotNull(q1, appAliases[q1])
        var best: Pair<String, Intent>? = null
        var bestScore = 0
        for (ri in pm.queryIntentActivities(main, 0)) {
            val label = ri.loadLabel(pm).toString()
            val l = label.lowercase().replace('ё', 'е')
            for (q in queries) {
                val score = when {
                    l == q -> 3
                    l.startsWith(q) || q.startsWith(l) -> 2
                    q.length >= 3 && (l.contains(q) || (l.length >= 3 && q.contains(l))) -> 1
                    else -> 0
                }
                if (score > bestScore) {
                    val launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
                    if (launch != null) { best = label to launch; bestScore = score }
                }
            }
        }
        return best
    }

    private fun openApp(name: String): Outcome {
        if (name.isBlank()) return Outcome.Reply("Что открыть, Босяра?")
        val found = findApp(name)
            ?: return Outcome.Reply(Personality.limit("Не нашла приложение «$name». Скажи название так, как оно подписано на иконке."))
        return Outcome.Confirm("Открыть «${found.first}»?") {
            start(found.second, "Открываю «${found.first}».")
        }
    }

    private fun openSettings(t: String): String {
        val (action, name) = when {
            t.contains("wi-fi") || t.contains("wifi") || t.contains("вай") -> Settings.ACTION_WIFI_SETTINGS to "Wi-Fi"
            t.contains("bluetooth") || t.contains("блютуз") -> Settings.ACTION_BLUETOOTH_SETTINGS to "Bluetooth"
            t.contains("звук") || t.contains("громкост") -> Settings.ACTION_SOUND_SETTINGS to "звука"
            t.contains("экран") || t.contains("яркост") -> Settings.ACTION_DISPLAY_SETTINGS to "экрана"
            t.contains("батаре") -> Settings.ACTION_BATTERY_SAVER_SETTINGS to "батареи"
            t.contains("приложен") -> Settings.ACTION_APPLICATION_SETTINGS to "приложений"
            else -> Settings.ACTION_SETTINGS to "системные"
        }
        return start(Intent(action), "Открыла настройки ($name).")
    }

    private fun notifications(): String {
        val list = CynNotificationListener.snapshot(6)
            ?: return Personality.limit("Чтобы читать уведомления, нужен доступ: вкладка «Права» → «Доступ к уведомлениям». Без него Android мне их не показывает.")
        if (list.isEmpty()) return Personality.ok("Уведомлений нет, Босяра. Тишина!")
        return "Вот что висит (читаю только по твоей просьбе):\n" + list.joinToString("\n") { "• $it" }
    }

    private suspend fun weather(t: String): String {
        var city = Regex("погод\\S*\\s*(?:в|во|для|на)?\\s*(.*)").find(t)?.groupValues?.get(1).orEmpty()
            .replace(Regex("\\b(сейчас|сегодня|завтра|там|пожалуйста|у нас)\\b"), "").trim()
        if (city.isBlank()) city = prefs.city
        if (city.isBlank()) return Personality.limit("Не знаю, где ты, Босяра. Скажи «погода в Москве» или впиши город в Настройках. Геолокацию я не трогаю.")
        val cands = listOf(city, city.dropLast(1), city.dropLast(1) + "а", city.dropLast(1) + "ь", city.dropLast(2)).distinct()
            .filter { it.length >= 2 }
        var geo: JSONObject? = null
        for (c in cands) {
            val res = Http.request("https://geocoding-api.open-meteo.com/v1/search?name=${enc(c)}&count=1&language=ru&format=json")
            geo = JSONObject(res).optJSONArray("results")?.optJSONObject(0)
            if (geo != null) break
        }
        if (geo == null) return Personality.limit("Не нашла город «$city».")
        val lat = geo.getDouble("latitude")
        val lon = geo.getDouble("longitude")
        val title = geo.optString("name", city)
        val res = Http.request(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto",
        )
        val cur = JSONObject(res).getJSONObject("current")
        val temp = Math.round(cur.getDouble("temperature_2m"))
        val feels = Math.round(cur.getDouble("apparent_temperature"))
        val wind = Math.round(cur.getDouble("wind_speed_10m"))
        return Personality.ok("$title: ${wmo(cur.getInt("weather_code"))}, $temp°C (ощущается как $feels°C), ветер $wind км/ч.")
    }

    private fun wmo(code: Int) = when (code) {
        0 -> "ясно"
        1, 2 -> "малооблачно"
        3 -> "пасмурно"
        45, 48 -> "туман"
        in 51..57 -> "морось"
        in 61..67 -> "дождь"
        in 71..77 -> "снег"
        in 80..82 -> "ливни"
        85, 86 -> "снегопад"
        in 95..99 -> "гроза"
        else -> "погода странная"
    }
}
