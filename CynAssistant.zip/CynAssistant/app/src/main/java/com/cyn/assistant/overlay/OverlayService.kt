package com.cyn.assistant.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.cyn.assistant.CynApp
import com.cyn.assistant.MainActivity
import com.cyn.assistant.R
import com.cyn.assistant.core.Assistant
import com.cyn.assistant.core.CynState
import com.cyn.assistant.core.Mood
import com.cyn.assistant.ui.CynAvatar
import com.cyn.assistant.ui.NeonYellow
import com.cyn.assistant.ui.rememberSprite
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.random.Random

/**
 * Плавающий персонаж. Два окна TYPE_APPLICATION_OVERLAY:
 *  1) окно персонажа — размером ровно с него (всё остальное на экране остаётся кликабельным);
 *  2) окно облачка с текстом — FLAG_NOT_TOUCHABLE, то есть пропускает все касания насквозь.
 * Живёт как foreground-служба с видимым уведомлением («Убрать» / «СТОП»).
 */
class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "com.cyn.assistant.OVERLAY_STOP"
        const val ACTION_HIDE = "com.cyn.assistant.OVERLAY_HIDE"
        const val CHANNEL = "cyn_overlay"
        const val NOTIF_ID = 11
        var running by mutableStateOf(false)
            private set
    }

    private lateinit var wm: WindowManager
    private val owner = OverlayOwner()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val a: Assistant get() = CynApp.assistant

    private var frame: DragFrame? = null
    private var bubbleView: ComposeView? = null
    private val bubbleText = mutableStateOf("")
    private val facingRight = mutableStateOf(false)
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var screenW = 0
    private var screenH = 0
    private var dragging = false
    private var walkJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
    private fun charW() = dp(110f * a.prefs.scale)
    private fun charH() = dp(132f * a.prefs.scale)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Син на экране", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)

        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }

        owner.create()
        addCharacter()
        owner.resume()
        running = true
        startWatchers()
    }

    private fun pi(action: String, code: Int) = PendingIntent.getService(
        this, code, Intent(this, OverlayService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(R.drawable.ic_stat_cyn)
        .setContentTitle("Син на экране")
        .setContentText("«Убрать» прячет её, «СТОП» останавливает всё")
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        )
        .addAction(0, "СТОП", pi(ACTION_STOP, 1))
        .addAction(0, "Убрать", pi(ACTION_HIDE, 2))
        .build()

    private fun baseParams(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT,
    )

    private fun addCharacter() {
        val dm = resources.displayMetrics
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        lp = baseParams(
            charW(), charH(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenW - charW()
            y = screenH - charH() - dp(96f)
        }
        val f = DragFrame(
            this,
            onDragStart = {
                dragging = true
                walkJob?.cancel()
                a.poke()
                a.setMood(Mood.SURPRISE)
            },
            onDragBy = { dx, dy ->
                lp.x = (lp.x + dx.toInt()).coerceIn(0, (screenW - lp.width).coerceAtLeast(0))
                lp.y = (lp.y + dy.toInt()).coerceIn(0, (screenH - lp.height).coerceAtLeast(0))
                applyPos()
            },
            onDragEnd = {
                dragging = false
                a.setMood(Mood.JOY, 1200)
                scope.launch { snapToEdge() }
            },
        )
        f.setViewTreeLifecycleOwner(owner)
        f.setViewTreeViewModelStoreOwner(owner)
        f.setViewTreeSavedStateRegistryOwner(owner)
        val cv = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent {
                OverlayCharacter(
                    a = a,
                    facingRight = facingRight.value,
                    onTap = { walkJob?.cancel(); a.onTap() },
                    onLong = { walkJob?.cancel(); a.listen() },
                )
            }
        }
        f.addView(cv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        wm.addView(f, lp)
        frame = f
    }

    private fun applyPos() {
        frame?.let { if (it.isAttachedToWindow) runCatching { wm.updateViewLayout(it, lp) } }
        updateBubblePos()
    }

    private fun updateBubblePos() {
        val v = bubbleView ?: return
        if (!v.isAttachedToWindow) return
        val onRight = lp.x + lp.width / 2 > screenW / 2
        bubbleLp.gravity = Gravity.BOTTOM or (if (onRight) Gravity.END else Gravity.START)
        bubbleLp.x = if (onRight) (screenW - (lp.x + lp.width)).coerceAtLeast(0) else lp.x
        bubbleLp.y = (screenH - lp.y).coerceAtLeast(0)
        runCatching { wm.updateViewLayout(v, bubbleLp) }
    }

    private fun showBubble(text: String) {
        bubbleText.value = text
        if (bubbleView != null) { updateBubblePos(); return }
        bubbleLp = baseParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        )
        val v = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent { BubbleContent(bubbleText.value) }
        }
        runCatching { wm.addView(v, bubbleLp) }.onSuccess {
            bubbleView = v
            updateBubblePos()
        }
    }

    private fun hideBubble() {
        bubbleView?.let { runCatching { wm.removeView(it) } }
        bubbleView = null
    }

    private suspend fun moveX(target: Int, stepPx: Int) {
        while (scope.isActive && abs(lp.x - target) > stepPx) {
            lp.x += if (target > lp.x) stepPx else -stepPx
            applyPos()
            delay(16)
        }
        lp.x = target
        applyPos()
    }

    private suspend fun snapToEdge() {
        val maxX = (screenW - lp.width).coerceAtLeast(0)
        val target = if (lp.x + lp.width / 2 < screenW / 2) 0 else maxX
        facingRight.value = target == 0
        moveX(target, dp(10f))
    }

    private suspend fun walk() {
        val maxX = (screenW - lp.width).coerceAtLeast(1)
        val target = if (lp.x > maxX / 2) Random.nextInt(0, maxX / 3 + 1) else Random.nextInt(maxX * 2 / 3, maxX + 1)
        facingRight.value = target > lp.x
        CynState.mood.value = Mood.WALK
        try {
            moveX(target, dp(3f))
        } finally {
            if (CynState.mood.value == Mood.WALK) CynState.mood.value = Mood.IDLE
        }
    }

    private fun startWatchers() {
        // размер персонажа из настроек
        scope.launch {
            snapshotFlow { a.prefs.scale }.collect {
                lp.width = charW(); lp.height = charH()
                lp.x = lp.x.coerceIn(0, (screenW - lp.width).coerceAtLeast(0))
                lp.y = lp.y.coerceIn(0, (screenH - lp.height).coerceAtLeast(0))
                applyPos()
            }
        }
        // облачко с текстом
        scope.launch {
            CynState.bubble.collect { text -> if (text.isNullOrBlank()) hideBubble() else showBubble(text) }
        }
        // прогулки по краю экрана (выключаются в настройках и в режиме энергосбережения)
        scope.launch {
            while (isActive) {
                delay(Random.nextLong(12_000, 30_000))
                val p = a.prefs
                if (p.walkEnabled && !p.energySaver && !dragging && CynState.mood.value == Mood.IDLE) {
                    walkJob = launch { walk() }
                    walkJob?.join()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> a.stopAll()
            ACTION_HIDE -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        hideBubble()
        frame?.let { runCatching { wm.removeView(it) } }
        frame = null
        if (running) owner.destroy()
        running = false
        CynState.bubble.value = null
        super.onDestroy()
    }
}

@Composable
private fun OverlayCharacter(a: Assistant, facingRight: Boolean, onTap: () -> Unit, onLong: () -> Unit) {
    val mood by CynState.mood.collectAsState()
    val sprite = rememberSprite(a.prefs.spritePath)
    CynAvatar(
        mood = mood,
        facingRight = facingRight,
        animate = !a.prefs.energySaver,
        sprite = sprite,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onTap = { onTap() }, onLongPress = { onLong() })
            },
    )
}

@Composable
private fun BubbleContent(text: String) {
    Box(
        Modifier
            .padding(2.dp)
            .widthIn(max = 230.dp)
            .background(Color(0xEE000000), CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
            .border(1.dp, NeonYellow, CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(text, color = Color(0xFFF5F5DC), fontSize = 13.sp, fontFamily = FontFamily.Monospace)
    }
}
