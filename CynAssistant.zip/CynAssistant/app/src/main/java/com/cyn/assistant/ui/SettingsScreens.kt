package com.cyn.assistant.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.collectAsState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.cyn.assistant.core.Assistant
import com.cyn.assistant.core.CynNotificationListener
import com.cyn.assistant.core.Llm
import com.cyn.assistant.core.Perms
import com.cyn.assistant.core.SecureStore
import com.cyn.assistant.core.Sprites
import com.cyn.assistant.core.WakeWordService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun SwitchRow(label: String, hint: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            if (hint != null) Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked, onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = NeonYellow),
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text("$label: ${"%.2f".format(value)}", style = MaterialTheme.typography.bodySmall)
        Slider(value, onChange, valueRange = range)
    }
}

@Composable
fun SettingsScreen(a: Assistant, onWakeToggle: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = a.prefs
    var keyInput by remember { mutableStateOf("") }
    var hasKey by remember { mutableStateOf(SecureStore.has(ctx)) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val path = withContext(Dispatchers.IO) { Sprites.import(ctx, uri) }
            if (path != null) {
                Sprites.delete(p.spritePath)
                p.spritePath = path
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        LocalBrainPanel(a)
        NeonPanel(title = "Внешность и размер") {
            SliderRow("Размер персонажа на экране", p.scale, 0.6f..1.8f) { p.scale = it }
            SwitchRow("Гуляет по краю экрана", "Иногда бегает вдоль низа экрана", p.walkEnabled) { p.walkEnabled = it }
            Spacer(Modifier.height(4.dp))
            Text("Свой спрайт: любая картинка (PNG/JPG), которая есть у тебя. Она заменит дрона и будет анимироваться.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton("Выбрать картинку") { picker.launch("image/*") }
                if (p.spritePath.isNotBlank()) GhostButton("Вернуть дрона") {
                    Sprites.delete(p.spritePath); p.spritePath = ""
                }
            }
        }

        NeonPanel(title = "Голос") {
            SwitchRow("Озвучивать ответы", null, p.voiceOut) { p.voiceOut = it }
            SliderRow("Скорость речи", p.ttsRate, 0.6f..1.6f) { p.ttsRate = it }
            SliderRow("Высота голоса", p.ttsPitch, 0.6f..2.0f) { p.ttsPitch = it }
            GhostButton("Проверить голос") { a.testVoice() }
            Spacer(Modifier.height(6.dp))
            SwitchRow(
                "«Син, слушай» (по желанию)",
                "Микрофон слушает в фоне, пока включено. В шторке висит уведомление с кнопкой «Выключить». Расходует батарею.",
                WakeWordService.running,
            ) { onWakeToggle(it) }
        }

        if (p.provider != "local") NeonPanel(title = "Облачный ИИ • отдельная оплата API") {
            Text("Облачный режим отправляет переписку выбранному провайдеру и может требовать оплаты. Для бесплатных локальных ответов включи переключатель выше.", style = MaterialTheme.typography.bodySmall)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (p.provider == "openai") NeonButton("OpenAI-совместимый") {} else GhostButton("OpenAI-совместимый") {
                    p.provider = "openai"; p.baseUrl = Llm.OPENAI_URL; p.model = Llm.OPENAI_MODEL
                }
                if (p.provider == "anthropic") NeonButton("Claude API") {} else GhostButton("Claude API") {
                    p.provider = "anthropic"; p.baseUrl = Llm.ANTHROPIC_URL; p.model = Llm.ANTHROPIC_MODEL
                }
            }
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(p.baseUrl, { p.baseUrl = it }, Modifier.fillMaxWidth(), label = { Text("Адрес API") }, singleLine = true)
            OutlinedTextField(p.model, { p.model = it }, Modifier.fillMaxWidth(), label = { Text("Модель") }, singleLine = true)
            OutlinedTextField(
                keyInput, { keyInput = it }, Modifier.fillMaxWidth(),
                label = { Text(if (hasKey) "API-ключ сохранён (введи новый, чтобы заменить)" else "API-ключ") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton("Сохранить ключ") {
                    if (keyInput.isNotBlank()) {
                        SecureStore.put(ctx, keyInput); keyInput = ""; hasKey = true
                    }
                }
                if (hasKey) GhostButton("Удалить ключ") { SecureStore.clear(ctx); hasKey = false }
            }
            Text(
                "Ключ шифруется (AES-256-GCM, ключ в Android Keystore). Твои сообщения уходят выбранному провайдеру.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        NeonPanel(title = "Прочее") {
            OutlinedTextField(p.city, { p.city = it }, Modifier.fillMaxWidth(), label = { Text("Город для погоды (по умолчанию)") }, singleLine = true)
            SwitchRow("Спрашивать подтверждение", "Перед будильником, таймером, запуском приложений и музыкой", p.confirmActions) { p.confirmActions = it }
            SwitchRow("Режим энергосбережения", "Без постоянных анимаций и прогулок, быстрее засыпает", p.energySaver) { p.energySaver = it }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PermRow(title: String, desc: String, granted: Boolean, action: String, onAction: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (granted) "● " else "○ ",
                color = if (granted) NeonYellow else Danger,
            )
            Text(title, style = MaterialTheme.typography.titleMedium)
        }
        Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        GhostButton(if (granted) "Настройки (отозвать)" else action, onClick = onAction)
    }
}

@Composable
fun PermissionsScreen(tick: Int, onRequestMic: () -> Unit, onRequestNotif: () -> Unit) {
    val ctx = LocalContext.current
    // tick меняется при возвращении из системных настроек, поэтому статусы пересчитываются
    val overlay = remember(tick) { Perms.overlay(ctx) }
    val mic = remember(tick) { Perms.mic(ctx) }
    val notif = remember(tick) { Perms.notif(ctx) }
    val access = remember(tick) { Perms.notifAccess(ctx) || CynNotificationListener.instance != null }
    var hasKey by remember(tick) { mutableStateOf(SecureStore.has(ctx)) }

    fun appSettings() = ctx.startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        NeonPanel(title = "Разрешения") {
            Text(
                "Ничего не включается само. Каждое разрешение выдаёшь и отзываешь ты, в системных настройках.",
                style = MaterialTheme.typography.bodySmall,
            )
            PermRow(
                "Поверх других приложений",
                "Нужно, чтобы Син сидела в углу экрана. Окно размером с неё, остальной экран кликабелен.",
                overlay, "Выдать",
            ) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }
            PermRow(
                "Микрофон",
                "Только по кнопке 🎤, долгому нажатию на Син или включённому «Син, слушай».",
                mic, "Выдать",
            ) { if (mic) appSettings() else onRequestMic() }
            PermRow(
                "Уведомления приложения",
                "Чтобы было видно уведомление службы с кнопками «Убрать» и «СТОП» (Android 13+).",
                notif, "Выдать",
            ) { if (notif) appSettings() else onRequestNotif() }
            PermRow(
                "Доступ к уведомлениям",
                "Необязательно. Нужен только для команды «покажи уведомления». Син ничего не сохраняет.",
                access, "Открыть настройки",
            ) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }

        NeonPanel(title = "Выдаются при установке") {
            Text(
                "Интернет (языковая модель, погода), будильники и таймеры через «Часы», уведомление службы. " +
                    "Эти разрешения Android считает обычными: отозвать можно только удалив приложение.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        NeonPanel(title = "Отзыв и удаление") {
            GhostButton("Открыть системные настройки приложения") { appSettings() }
            Spacer(Modifier.height(6.dp))
            if (hasKey) GhostButton("Удалить API-ключ") { SecureStore.clear(ctx); hasKey = false }
            else Text("API-ключ не сохранён.", style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.size(24.dp))
    }
}


@Composable
private fun LocalBrainPanel(a: Assistant) {
    val state by a.localModel.state.collectAsState()
    var mobile by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val local = a.prefs.provider == "local"
    NeonPanel(title = "ИИ • локальный мозг Син 0.2.1") {
        SwitchRow("Отвечать на телефоне", "Без API-ключа и оплаты за запросы", local) {
            a.stopAll()
            a.prefs.provider = if (it) "local" else "openai"
        }
        if (local) {
            Text("Qwen2.5 1.5B • 1,12 ГБ", color = NeonYellow)
            Text("Обновление: обычные ответы без навязанных прибауток. Нужна новая модель; прежняя удалится только после успешной загрузки новой.", style = MaterialTheme.typography.bodySmall)
            Text("Готовая открытая нейросеть для обычного диалога. Проще облачного GPT; может ошибаться. Обрабатывает короткие сообщения и последние реплики.", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Text(state.message, style = MaterialTheme.typography.bodyMedium)
            if (state.busy) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth(), color = NeonYellow)
                GhostButton("Отменить загрузку / проверку") { a.localModel.remove() }
            } else if (state.ready) {
                Text("Можно выключить интернет и написать Син в чате. Модель каждый раз загружается в память; первый ответ может занять время.", style = MaterialTheme.typography.bodySmall)
                GhostButton("Удалить модель (1,12 ГБ)") { confirmDelete = true }
            } else {
                SwitchRow("Разрешить мобильный интернет", "Выключено — загрузка только по Wi-Fi", mobile) { mobile = it }
                NeonButton("Скачать модель • 1,12 ГБ") { a.localModel.download(mobile) }
            }
            Spacer(Modifier.height(6.dp))
            Text("Текстовые ответы локальные. Погода и системное распознавание речи могут требовать интернет. Нейросеть не обучается на переписке автоматически.", style = MaterialTheme.typography.bodySmall)
            Text("Модель: Qwen, Apache 2.0. Движок: llama.cpp, MIT. Лицензии включены в приложение.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Удалить локальную модель?") },
        text = { Text("История и настройки останутся. Для новых ответов понадобится снова скачать 1,12 ГБ.") },
        confirmButton = { TextButton(onClick = { a.stopAll(); a.localModel.remove(); confirmDelete = false }) { Text("Удалить") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } },
    )
}
