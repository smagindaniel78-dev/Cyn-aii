package com.cyn.assistant.core

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import kotlin.reflect.KProperty

/** Настройка, которая хранится в SharedPreferences и при этом наблюдаема из Compose. */
class Pref<T : Any>(
    private val sp: SharedPreferences,
    private val key: String,
    private val def: T,
) {
    private val state = mutableStateOf(load())

    @Suppress("UNCHECKED_CAST")
    private fun load(): T = when (def) {
        is Boolean -> sp.getBoolean(key, def)
        is Float -> sp.getFloat(key, def)
        is String -> sp.getString(key, def) ?: def
        else -> def
    } as T

    operator fun getValue(thisRef: Any?, property: KProperty<*>): T = state.value

    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        state.value = value
        val e = sp.edit()
        when (value) {
            is Boolean -> e.putBoolean(key, value)
            is Float -> e.putFloat(key, value)
            is String -> e.putString(key, value)
        }
        e.apply()
    }
}

/** Все пользовательские настройки. API-ключ тут НЕ хранится (см. SecureStore). */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cyn_prefs", Context.MODE_PRIVATE)

    init {
        // One-time switch for this requested offline update; retain keys and other settings.
        if (!sp.getBoolean("local_v2", false)) sp.edit().putString("provider", "local").putBoolean("local_v2", true).apply()
    }
    // Ignore pre-update dialogue as generation context without deleting visible history.
    init {
        if (!sp.contains("plain_dialog_since")) sp.edit().putString("plain_dialog_since", System.currentTimeMillis().toString()).apply()
    }
    val plainDialogSince: Long get() = sp.getString("plain_dialog_since", "0")?.toLongOrNull() ?: 0L

    var provider by Pref(sp, "provider", "local")          // "openai" (совместимый API) | "anthropic"
    var baseUrl by Pref(sp, "baseUrl", "https://api.openai.com/v1")
    var model by Pref(sp, "model", "gpt-4o-mini")
    var city by Pref(sp, "city", "")

    var scale by Pref(sp, "scale", 1f)                       // размер персонажа на экране
    var walkEnabled by Pref(sp, "walk", true)                // ходит по краю экрана
    var spritePath by Pref(sp, "sprite", "")                 // свой PNG-спрайт (необязательно)

    var voiceOut by Pref(sp, "voiceOut", true)
    var ttsRate by Pref(sp, "ttsRate", 1.05f)
    var ttsPitch by Pref(sp, "ttsPitch", 1.3f)

    var energySaver by Pref(sp, "energy", false)
    var confirmActions by Pref(sp, "confirm", true)          // спрашивать подтверждение перед действиями
}
