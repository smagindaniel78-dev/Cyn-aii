package com.cyn.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.cyn.assistant.core.Assistant
import com.cyn.assistant.core.CynState
import com.cyn.assistant.core.Msg
import com.cyn.assistant.overlay.OverlayService

private val userShape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)

@Composable
fun ChatScreen(a: Assistant, onMic: () -> Unit, onToggleOverlay: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val mood by CynState.mood.collectAsState()
    val sprite = rememberSprite(a.prefs.spritePath)
    val msgs = a.repo.history.takeLast(40).reversed()

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        NeonPanel(title = if (a.prefs.provider == "local") "Син • локальный ИИ" else "Син • облачный ИИ") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CynAvatar(
                    mood = mood,
                    modifier = Modifier.size(90.dp, 108.dp),
                    animate = !a.prefs.energySaver,
                    sprite = sprite,
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(a.status, color = MaterialTheme.colorScheme.onSurface, maxLines = 5, style = MaterialTheme.typography.bodyMedium)
                    NeonButton(if (OverlayService.running) "Спрятать Син" else "Показать Син на экране", onClick = onToggleOverlay)
                }
            }
        }

        a.pending?.let { p ->
            NeonPanel(title = "Подтверди действие") {
                Text(p.question, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("ДА") { a.confirm(true) }
                    GhostButton("НЕТ") { a.confirm(false) }
                }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            reverseLayout = true,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(msgs) { MsgBubble(it) }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Напиши Син...") },
                maxLines = 3,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSend = {
                    a.submit(input); input = ""
                }),
            )
            GhostButton("🎤", onClick = onMic)
            NeonButton("➤") { a.submit(input); input = "" }
        }
    }
}

@Composable
private fun MsgBubble(m: Msg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .then(
                    if (m.fromUser) Modifier.background(NeonYellow, userShape)
                    else Modifier.background(PanelBg, userShape).border(1.dp, DimYellow, userShape)
                )
                .padding(horizontal = 10.dp, vertical = 6.dp),
        ) {
            Text(
                m.text,
                color = if (m.fromUser) Color.Black else SoftWhite,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
fun HistoryScreen(a: Assistant) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        NeonPanel(title = "История диалогов") {
            Text("Хранится только на этом телефоне. Сообщений: ${a.repo.history.size}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            GhostButton("Очистить историю") { confirm = true }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(a.repo.history.reversed()) { MsgBubble(it) }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Очистить историю?") },
            text = { Text("Все сообщения будут удалены без возможности восстановления.") },
            confirmButton = { TextButton({ a.repo.clearHistory(); confirm = false }) { Text("Очистить", color = Danger) } },
            dismissButton = { TextButton({ confirm = false }) { Text("Отмена") } },
        )
    }
}

@Composable
fun MemoryScreen(a: Assistant) {
    var newItem by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            NeonPanel(title = "Что Син помнит о тебе") {
                Text(
                    "Син запоминает только то, что ты сам попросил («запомни, что я люблю чай») или добавил здесь. " +
                        "Этот список уходит в языковую модель вместе с твоими сообщениями. Удалить можно в любой момент.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(newItem, { newItem = it }, Modifier.weight(1f), placeholder = { Text("Добавить факт") }, maxLines = 2)
                    NeonButton("+") { a.repo.addMemory(newItem); newItem = "" }
                }
            }
        }
        itemsIndexed(a.repo.memory) { i, text ->
            NoteRow(text) { a.repo.removeMemory(i) }
        }
        if (a.repo.memory.isNotEmpty()) item { GhostButton("Забыть всё") { confirm = true } }

        item {
            NeonPanel(title = "Заметки (внутри приложения)") {
                Text("Сюда попадает «создай заметку ...». В другие приложения Син не пишет.", style = MaterialTheme.typography.bodySmall)
            }
        }
        itemsIndexed(a.repo.notes) { i, text -> NoteRow(text) { a.repo.removeNote(i) } }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Забыть всё?") },
            text = { Text("Все запомненные факты будут удалены.") },
            confirmButton = { TextButton({ a.repo.clearMemory(); confirm = false }) { Text("Забыть", color = Danger) } },
            dismissButton = { TextButton({ confirm = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun NoteRow(text: String, onDelete: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(PanelBg, userShape)
            .border(1.dp, DimYellow, userShape)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text("✕", color = Danger, modifier = Modifier.clickable(onClick = onDelete).padding(8.dp))
    }
}
