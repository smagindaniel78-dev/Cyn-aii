package com.cyn.assistant.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Минимальный HTTP-клиент без зависимостей. Запрос обрывается при отмене корутины (кнопка СТОП). */
object Http {
    suspend fun request(
        url: String,
        method: String = "GET",
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
    ): String = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        val handle = coroutineContext[Job]?.invokeOnCompletion { if (it != null) conn.disconnect() }
        try {
            conn.requestMethod = method
            conn.connectTimeout = 12_000
            conn.readTimeout = 40_000
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("HTTP $code: ${text.take(200)}")
            text
        } finally {
            handle?.dispose()
            conn.disconnect()
        }
    }
}
