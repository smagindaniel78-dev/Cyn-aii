package com.cyn.assistant.core

import android.app.Notification
import android.service.notification.NotificationListenerService

/**
 * Работает ТОЛЬКО если пользователь сам включил «Доступ к уведомлениям» в системных настройках.
 * Ничего не сохраняет и не отправляет: уведомления читаются в момент команды «покажи уведомления».
 */
class CynNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }

    companion object {
        @Volatile
        var instance: CynNotificationListener? = null

        /** null = доступ не выдан. */
        fun snapshot(max: Int): List<String>? {
            val svc = instance ?: return null
            return runCatching {
                svc.activeNotifications
                    .filter { it.packageName != svc.packageName }
                    .sortedByDescending { it.postTime }
                    .take(max)
                    .map { sbn ->
                        val pm = svc.packageManager
                        val app = runCatching {
                            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
                        }.getOrDefault(sbn.packageName)
                        val ex = sbn.notification.extras
                        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
                        "$app: ${listOf(title, text).filter { it.isNotBlank() }.joinToString(" — ")}"
                    }
            }.getOrNull()
        }
    }
}
