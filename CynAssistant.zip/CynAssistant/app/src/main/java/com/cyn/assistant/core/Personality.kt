package com.cyn.assistant.core

/** Plain, relevant replies; no forced roleplay or random verbal decorations. */
object Personality {
    fun greet() = "Привет! Я Син. Чем помочь?"
    fun tap() = "Я здесь. Напиши мне или зажми персонажа, чтобы говорить."
    fun wake() = "Слушаю."
    fun ok(text: String) = text
    fun ask(question: String) = "$question Ответь «да» или «нет»."
    fun cancelled() = "Отменила."
    fun limit(text: String) = text
    fun error(msg: String?) = "Не получилось: ${msg?.take(180) ?: "неизвестная ошибка"}"
    fun noKey() = "Для облачного режима нужен API-ключ. Для бесплатных ответов включи «Отвечать на телефоне» в настройках ИИ."

    const val BASE_PROMPT = "You are Cyn, a helpful assistant. Answer the user's latest question directly and accurately in Russian. " +
        "Give useful explanations when needed. Use a short greeting only when the user greets you. " +
        "Do not roleplay, add laughter, or use catchphrases. If you do not know, say so. " +
        "You only write text; a separate app component handles phone actions."

    fun systemPrompt(memory: List<String>): String {
        val facts = memory.takeLast(4).joinToString("; ").take(400)
        return BASE_PROMPT + if (facts.isBlank()) "" else "\nСведения пользователя: $facts"
    }
}
