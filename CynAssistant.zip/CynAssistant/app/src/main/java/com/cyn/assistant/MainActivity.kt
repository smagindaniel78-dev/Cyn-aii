package com.cyn.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.cyn.assistant.core.Perms
import com.cyn.assistant.core.WakeWordService
import com.cyn.assistant.overlay.OverlayService
import com.cyn.assistant.ui.ChatScreen
import com.cyn.assistant.ui.CynTheme
import com.cyn.assistant.ui.DeepBlack
import com.cyn.assistant.ui.DimYellow
import com.cyn.assistant.ui.HistoryScreen
import com.cyn.assistant.ui.MemoryScreen
import com.cyn.assistant.ui.NeonYellow
import com.cyn.assistant.ui.PermissionsScreen
import com.cyn.assistant.ui.SettingsScreen
import com.cyn.assistant.ui.StopButton

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { CynTheme { CynRoot() } }
    }
}

private data class Tab(val label: String, val icon: String)

private val tabs = listOf(
    Tab("Син", "👾"),
    Tab("Память", "🧠"),
    Tab("История", "💬"),
    Tab("Права", "🔐"),
    Tab("Настройки", "⚙"),
)

@Composable
private fun CynRoot() {
    val a = CynApp.assistant
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }

    // тик обновляется при каждом возвращении в приложение: пересчитываем статусы разрешений
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    fun startOverlay() {
        ContextCompat.startForegroundService(ctx, Intent(ctx, OverlayService::class.java))
    }

    fun startWake() {
        ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java))
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) a.listen()
    }
    val wakeMicLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startWake()
    }
    val notifOnlyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val notifThenOverlay = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        startOverlay() // служба работает и без уведомления, просто оно будет скрыто системой
    }

    fun toggleOverlay() {
        when {
            OverlayService.running ->
                ctx.startService(Intent(ctx, OverlayService::class.java).setAction(OverlayService.ACTION_HIDE))
            !Perms.overlay(ctx) -> {
                Toast.makeText(ctx, "Разреши «Поверх других приложений» для CYN Assistant", Toast.LENGTH_LONG).show()
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }
            Build.VERSION.SDK_INT >= 33 && !Perms.notif(ctx) ->
                notifThenOverlay.launch(Manifest.permission.POST_NOTIFICATIONS)
            else -> startOverlay()
        }
    }

    fun onMic() {
        if (Perms.mic(ctx)) a.listen() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun onWakeToggle(on: Boolean) {
        if (!on) {
            ctx.stopService(Intent(ctx, WakeWordService::class.java))
        } else if (!Perms.mic(ctx)) {
            wakeMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else startWake()
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        containerColor = DeepBlack,
        topBar = {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                    .padding(top = 28.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("CYN//ASSISTANT", color = NeonYellow, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                // Кнопка экстренной остановки доступна на любом экране
                StopButton { a.stopAll() }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A0A06)) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(t.icon) },
                        label = { Text(t.label, style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = NeonYellow,
                            unselectedTextColor = DimYellow,
                            indicatorColor = Color(0xFF2A2800),
                        ),
                    )
                }
            }
        },
    ) { inner ->
        androidx.compose.foundation.layout.Box(Modifier.padding(inner)) {
            when (tab) {
                0 -> ChatScreen(a, onMic = ::onMic, onToggleOverlay = ::toggleOverlay)
                1 -> MemoryScreen(a)
                2 -> HistoryScreen(a)
                3 -> PermissionsScreen(
                    tick = tick,
                    onRequestMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    onRequestNotif = {
                        if (Build.VERSION.SDK_INT >= 33) notifOnlyLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    },
                )
                else -> SettingsScreen(a, onWakeToggle = ::onWakeToggle)
            }
        }
    }
}
