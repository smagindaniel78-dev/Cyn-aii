package com.cyn.assistant

import android.app.Application
import com.cyn.assistant.core.Assistant

class CynApp : Application() {
    lateinit var assistant: Assistant
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        assistant = Assistant(this)
    }

    companion object {
        lateinit var instance: CynApp
            private set
        val assistant: Assistant get() = instance.assistant
    }
}
