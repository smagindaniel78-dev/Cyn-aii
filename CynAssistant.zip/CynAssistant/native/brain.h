#pragma once
#include <string>
#include <cstdint>
int64_t brain_epoch();
void brain_cancel();
std::string brain_generate(const std::string &path, const std::string &prompt, int64_t epoch);
