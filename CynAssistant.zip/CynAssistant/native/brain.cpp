#include "brain.h"
#include "llama.h"
#include <atomic>
#include <algorithm>
#include <chrono>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <thread>
#include <vector>

static std::atomic<int64_t> cancellation{0};
static std::mutex engine_mutex;
static std::once_flag initialized;
int64_t brain_epoch() { return cancellation.load(); }
void brain_cancel() { cancellation.fetch_add(1); }
struct Run {
    int64_t epoch;
    std::chrono::steady_clock::time_point deadline;
};
static bool aborted(void *data) {
    auto *r = static_cast<Run *>(data);
    return cancellation.load() != r->epoch || std::chrono::steady_clock::now() > r->deadline;
}
static bool loading(float, void *data) { return !aborted(data); }

std::string brain_generate(const std::string &path, const std::string &prompt, int64_t epoch) {
    std::lock_guard<std::mutex> guard(engine_mutex);
    Run run{epoch, std::chrono::steady_clock::now() + std::chrono::seconds(150)};
    if (aborted(&run)) return "";
    std::call_once(initialized, [] {
        llama_log_set([](ggml_log_level, const char *, void *) {}, nullptr);
        llama_backend_init();
    });
    auto mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    mp.use_mmap = true;
    mp.progress_callback = loading;
    mp.progress_callback_user_data = &run;
    std::unique_ptr<llama_model, decltype(&llama_model_free)> model(
        llama_model_load_from_file(path.c_str(), mp), llama_model_free);
    if (!model) {
        if (aborted(&run)) return "";
        throw std::runtime_error("Не удалось загрузить модель. Закрой тяжёлые приложения или скачай её заново.");
    }
    auto *vocab = llama_model_get_vocab(model.get());
    int n = -llama_tokenize(vocab, prompt.data(), prompt.size(), nullptr, 0, true, true);
    if (n <= 0 || n > 1792) throw std::runtime_error("Сообщение слишком длинное. Напиши короче.");
    std::vector<llama_token> tokens(n);
    if (llama_tokenize(vocab, prompt.data(), prompt.size(), tokens.data(), n, true, true) < 0)
        throw std::runtime_error("Не удалось прочитать сообщение.");
    auto cp = llama_context_default_params();
    cp.n_ctx = 2048;
    cp.n_batch = 256;
    cp.n_ubatch = 128;
    cp.n_threads = std::min(4u, std::max(1u, std::thread::hardware_concurrency()));
    cp.n_threads_batch = cp.n_threads;
    cp.abort_callback = aborted;
    cp.abort_callback_data = &run;
    std::unique_ptr<llama_context, decltype(&llama_free)> ctx(llama_init_from_model(model.get(), cp), llama_free);
    if (!ctx) throw std::runtime_error("Не хватает памяти для ИИ. Закрой другие приложения.");
    auto sp = llama_sampler_chain_default_params();
    std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)> sampler(llama_sampler_chain_init(sp), llama_sampler_free);
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_temp(0.2f));
    llama_sampler_chain_add(sampler.get(), llama_sampler_init_dist(42));
    for (int offset = 0; offset < n; offset += 256) {
        if (aborted(&run)) return "";
        auto batch = llama_batch_get_one(tokens.data() + offset, std::min(256, n - offset));
        if (llama_decode(ctx.get(), batch)) {
            if (aborted(&run)) return "";
            throw std::runtime_error("Не удалось обработать запрос. Попробуй короче.");
        }
    }
    std::string out;
    for (int i = 0; i < 192; ++i) {
        if (aborted(&run)) break;
        auto token = llama_sampler_sample(sampler.get(), ctx.get(), -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        char buf[256];
        int len = llama_token_to_piece(vocab, token, buf, sizeof(buf), 0, false);
        if (len >= 0) out.append(buf, len);
        else {
            std::vector<char> large(-len);
            int actual = llama_token_to_piece(vocab, token, large.data(), large.size(), 0, false);
            if (actual > 0) out.append(large.data(), actual);
        }
        auto batch = llama_batch_get_one(&token, 1);
        if (llama_decode(ctx.get(), batch)) {
            if (aborted(&run)) break;
            throw std::runtime_error("Не удалось закончить ответ.");
        }
    }
    if (cancellation.load() != epoch) return "";
    if (out.empty() && aborted(&run)) throw std::runtime_error("Ответ занял слишком долго. Попробуй короткий вопрос.");
    return out;
}
