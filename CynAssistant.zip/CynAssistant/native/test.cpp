#include "brain.h"
#include <iostream>
#include <fstream>
#include <iterator>
#include <thread>
#include <chrono>
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    std::ifstream f(argv[2]);
    std::string prompt((std::istreambuf_iterator<char>(f)), {});
    const auto before = brain_epoch();
    brain_cancel();
    if (!brain_generate(argv[1], prompt, before).empty()) return 3;
    try { brain_generate("/missing/model.gguf", prompt, brain_epoch()); return 4; }
    catch (const std::exception &) {}
    std::string cancelled;
    auto epoch = brain_epoch();
    std::thread t([&] { cancelled = brain_generate(argv[1], prompt, epoch); });
    std::this_thread::sleep_for(std::chrono::milliseconds(400));
    brain_cancel(); t.join();
    if (!cancelled.empty()) return 5;
    auto output = brain_generate(argv[1], prompt, brain_epoch());
    std::cout << output << std::endl;
    return output.empty() ? 6 : 0;
}
