#include <jni.h>
#include "brain.h"
#include <exception>
extern "C" JNIEXPORT jlong JNICALL
Java_com_cyn_assistant_core_NativeBrain_epoch(JNIEnv *, jobject) { return brain_epoch(); }
extern "C" JNIEXPORT void JNICALL
Java_com_cyn_assistant_core_NativeBrain_cancel(JNIEnv *, jobject) { brain_cancel(); }
extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_cyn_assistant_core_NativeBrain_generate(JNIEnv *env, jobject, jstring path, jbyteArray bytes, jlong epoch) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    if (!p) return nullptr;
    std::string model_path(p);
    env->ReleaseStringUTFChars(path, p);
    auto len = env->GetArrayLength(bytes);
    std::string prompt(len, '\0');
    env->GetByteArrayRegion(bytes, 0, len, reinterpret_cast<jbyte *>(prompt.data()));
    if (env->ExceptionCheck()) return nullptr;
    try {
        auto result = brain_generate(model_path, prompt, epoch);
        auto out = env->NewByteArray(result.size());
        if (out) env->SetByteArrayRegion(out, 0, result.size(), reinterpret_cast<const jbyte *>(result.data()));
        return out;
    } catch (const std::exception &e) {
        // ThrowNew expects modified UTF-8; messages contain BMP Cyrillic only.
        env->ThrowNew(env->FindClass("java/lang/IllegalStateException"), e.what());
        return nullptr;
    }
}
